# Slice Rush Mobile

Touch-first Fruit-Ninja-style browser game.

## GitHub Pages

The workflow in `.github/workflows/pages.yml` deploys the repository root to GitHub Pages on every push to `main`.
